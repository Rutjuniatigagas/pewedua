<?php 

namespace app;

/**
* Root controller
*/
class Controller
{
	public $attribut = true;
}