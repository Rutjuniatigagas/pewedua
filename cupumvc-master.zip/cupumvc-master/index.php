<?php

require_once('bootstrap.php');
$run->$action();