<?php 

namespace model;

use app\Model;


/**
* 
*/
class Mahasiswa extends Model
{
	public function ambilSemua()
	{
		$pesan = "Berhasil";
		return $pesan;
	}
}

