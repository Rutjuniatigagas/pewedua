<?php 

$nama_aplikasi = 'Cupu MVC';

// database
$namahost 	= 'localhost';
$dbusername = 'root';
$dbpassword = 'passwordnya';
$dbname 	= 'namadatabase';


 ?>