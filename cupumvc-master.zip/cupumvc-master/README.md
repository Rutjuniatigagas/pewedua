# CupuMVC

Ini merupakan contoh dari MVC sekedar untuk pembelajaran. Bukan untuk produksi.
Hanya sekedar untuk memberikan contoh penerapan MVC pada php.
- Template menggunakan Gentelella
- Routing terinspirasi dari Yii2

## Cara Menggunakan
1. Silahkan rename file yang ada di main.sample.php menjadi main.php
2. Untuk mengaksesnya silahkan coba akses http://hostnameanda/path/site/index maka ia akan masuk ke controller bernama site dan action bernama index

Untuk produksi saya menyarankan gunakan saja Yii2, CodeIgniter atau Laravel


